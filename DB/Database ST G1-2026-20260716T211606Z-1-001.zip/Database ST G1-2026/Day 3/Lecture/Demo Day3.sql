﻿﻿----------------------------------------------------------
-------------------------- Joins --------------------------
-----------------------------------------------------------
--------------------------------
-- Cross Join (Cartisian product)
----------------------------------

select*
from Student --11

select*
from Department --5

select * 
from Student cross join Department

select * 
from Student , Department

----------------------------------
-- Inner Join (Equi Join)
----------------------------------
select St_Fname, Dept_Name
from Student S , Department D --dnum deptid
where S.Dept_Id = D.Dept_Id
-- where dnum = deptid

select St_Fname, Dept_Name
from Student S inner join Department D --dnum deptid
on S.Dept_Id = D.Dept_Id

----------------------------------
-- Outer Joins 
--------------------------------
-- 1. Left Outer Join 
-----------------------

--11
select St_Fname, Dept_Name
from Student S left outer join Department D
on S.Dept_Id = D.Dept_Id

--5  --returned records = 9 (1-m relationship)
select St_Fname, Dept_Name
from Department D left outer join Student S
on S.Dept_Id = D.Dept_Id


------------------------------
-- 2. Right Outer Join 
-----------------------
select St_Fname, Dept_Name
from Student S right join Department D
on S.Dept_Id = D.Dept_Id

----------------------
-- 3. Full Outer Join 
-----------------------

select St_Fname, Dept_Name
from Student S Full outer join Department D
on S.Dept_Id = D.Dept_Id

--------------------------------------------------------------
-- Self Join
--------------------------------------------
select std.St_Id, std.St_Fname, super.St_Fname
from Student Std, Student Super
where Super.St_Id = std.St_super

--another case 
select std.St_Id, std.St_Fname, super.St_Fname
from Student Std, Student Super
where std.St_Id = super.St_super

------------------------
-- Multiple-Table Joins 
------------------------
select St_Fname, Crs_Name, Grade
from Student s, Course crs, Stud_Course stdcrs
where s.St_Id = stdcrs.St_Id  and stdcrs.Crs_Id = crs.Crs_Id and Grade > 90

select St_Fname, Crs_Name, Grade
from Student s 
inner join Stud_Course stdcrs 
on s.St_Id = stdcrs.St_Id  
inner join Course crs
on stdcrs.Crs_Id = crs.Crs_Id  
where Grade > 90

select St_Fname, Crs_Name, Grade
from Student s 
inner join Stud_Course stdcrs 
on s.St_Id = stdcrs.St_Id  
inner join Course crs
on stdcrs.Crs_Id = crs.Crs_Id and Grade > 90

------------------------
-- DML With Joins - DQL
-----------------------

-- update 
update Stud_Course
set Grade += 10 --grade = grade +10
from Student inner join Stud_Course
on Student.St_Id = Stud_Course.St_Id
where St_Address = 'Cairo'


select * 
from Student inner join Stud_Course
on Student.St_Id = Stud_Course.St_Id
where St_Address = 'Cairo'


-- delete
-- delete from Stud_Course
-- where
delete Stud_Course
from Student inner join Stud_Course
on Student.St_Id = Stud_Course.St_Id
where St_Address = 'Cairo'

----------------------------------------------
--------------- Functions ----------------------
--------------------------------------------
use MyCompany

------------ Aggregate Functions ---------------
--count 
select COUNT(*)
from Employee

select Count (Dno)
from Employee

select * from Employee

--integrals only
--sum 
select Sum(salary)
from Employee

select Sum(Fname)
from Employee
--avg
select Avg(salary)
from Employee

select Sum(salary)/ Count(*)
from Employee

--max
select Max(Salary)
from Employee

select Max(Fname)
from Employee

--min
select min(Salary)
from Employee

select min(Fname)
from Employee


------------ Null Functions -------------
-- is null
select FName + ' '+ Lname 
from Employee


select isnull(Fname,'no firstname') + ' ' + isnull(Lname, '')
from Employee

select ISNULL(salary,'no slaary') 
from Employee
--Conversion failed when converting the varchar value 'no slaary' to data type int.

select isnull(Salary, '999') --compatible datatype
from Employee

-- Coalesce
select Fname, Coalesce(Lname, Address, ' ')
from Employee

select Fname, isnull(Lname, isnull(Address, 'nothing'))
from Employee


------------ Date and Time Functions ---------------

Select SysDateTime() -- 2024-11-14 08:30:08.1571479

Select SYSUTCDATETIME() -- 2024-11-14 06:30:42.2019742

Select GetDate() -- 2024-11-14 08:31:07.643

Select GETUTCDATE() -- 2024-11-14 06:31:24.023

Select DATENAME(day, '11-14-2024') -- 14

Select DATEPART(day ,'11-14-2024') -- 14

Select DATENAME(weekday, '11-14-2024') -- Thursday

Select DAY('11-14-2024') -- 14

Select Month('11-14-2024') -- 11

Select YEAR('11-14-2024') -- 2024

Select EOMONTH ('11-14-2024') -- 2024-11-30

Select ISDATE('11-14-2024') -- 1 --m-d-y

Select ISDATE('14-11-2024') -- 0

------------ Conversion Functions ---------------
--convert
select Fname +' ' + isnull(convert(varchar(20),Salary),' ')
from Employee

select convert(varchar(20), GetDate(),10)
select convert(varchar(20), GetDate(),100)
select convert(varchar(20), GetDate(),106)

--cast
select Fname +' ' + isnull(cast(Salary as varchar(20)),' ')
from Employee

---parse date int
--string -- date, int --error (not safe)
select parse('Tuesday, 5 November 2024' as int)
--try-parse --return result , return null (safe)
select Try_Parse('Tuesday, 5 November 2024' as date)


------------ String Functions ---------------
Select Fname + ' ' + Lname --unsafe 
From Employee

--uses isnull
select Concat(Fname, ' ', Lname)
from Employee

select Concat_WS('_', Fname, Lname, Address)
from Employee

select lower (Fname), UPPER(Fname)
from Employee

select len (Fname)
from Employee

select Fname , Substring(Fname, 1,3) --starting idenx, len
from Employee

-------------------------------------------------------------------------------------
------------------------------ Format ------------------------------------------------
--date --numbers
Select FORMAT(Salary , '###,###')
From Employee

Select FORMAT(123456789 , '###,###,###')

Declare @Today datetime = GETDATE()
SELECT FORMAT(@Today, 'd', 'en-US')	-- 11/14/2024	
SELECT FORMAT(@Today, 'd', 'ar-SA') -- 12/05/46
SELECT FORMAT(@Today, 'D', 'en-US')  -- Thursday, November 14, 2024
SELECT FORMAT(@Today, 'D', 'ar-SA') -- 12/جمادى الأولى/1446
Select FORMAT(@Today , 'dd MM yy') -- 14 11 24
Select FORMAT(@Today , 'ddd MMM yyy') -- Thu Nov 2024
Select FORMAT(@Today , 'dddd MMMM yyyy') -- Thursday November 2024
Select FORMAT(@Today , 'dd-MM-yyyy hh:mm:ss tt' , 'en-US') -- 14-11-2024 09:32:36 AM
Select FORMAT(@Today , 'dd-MM-yyyy hh:mm:ss tt' , 'ar-SA') --12-05-1446 09:32:36 ص

---------------------------------------------------------------------------------------

--===================================================================
-------------------------    Group By    ----------------------------
--===================================================================
use ITI

select Dept_Id, Min(Salary) [min salary per dept]
from Instructor
where Dept_Id is not null
group by Dept_Id

/*
Msg 8120, Level 16, State 1, Line 250
Column 'Instructor.Ins_Name' is invalid in the select list because it is not contained in either an aggregate function or the GROUP BY clause.
*/

------------------------
--Group By With Multiple Columns 
------------------------------
select Dept_Id, Ins_Name, Min(Salary) [min salary per dept]
from Instructor
where Dept_Id is not null
group by Dept_Id, Ins_Name

------------------------------------ 
-- Group By With Having 
------------------------------------

--where go with rows before group by
--having - partitions  after group by
select Dept_Id, COUNT(*)
from Student
where Dept_Id is not null  and COUNT(*) > 2 --invalid
group by Dept_Id

select Dept_Id, COUNT(*)
from Student
where Dept_Id is not null  
group by Dept_Id
HAving COUNT(*) > 3

select Avg(Salary)
from Instructor
Having Count(*) > 10 --without grouping

-----------------------------------
-- Group By With Join 
-------------------------------------

select Instructor.Dept_Id, Dept_Name, Sum(Salary)
from Instructor inner join Department
on Department.Dept_Id = Instructor.Dept_Id
group by Instructor.Dept_Id, Dept_Name

---------------------------------
-- Sub Query 
---------------------------------
-- Select Student Id , Student First Name , Student Age Of Student 
-- That Their Age Is More Than Average Of All Student
------------------------

select St_Id, St_Fname, St_Age
from Student
where St_Age > Avg(St_Age) --invalid
--An aggregate may not appear in the WHERE clause unless it is in a subquery contained in a HAVING clause or a select list, and the column being aggregated is an outer reference.


select St_Id, St_Fname, St_Age
from Student
Having St_Age > Avg(St_Age) --invalid
--Column 'Student.St_Age' is invalid in the HAVING clause because it is not contained in either an aggregate function or the GROUP BY clause.

select St_Id, St_Fname, St_Age
from Student
Having Avg(St_Age) < St_Age --invalid

-- Column 'Student.St_Age' is invalid in the HAVING clause because it is not contained in either an aggregate function or the GROUP BY clause.

select Avg(St_Age)
from Student

select St_Id, St_Fname, St_Age
from Student
where St_Age > (select Avg(St_Age)
from Student)


select St_ID, Count(*)
from Student --invalid

select St_ID, (select Count(*)from Student)
from Student 

-------------------------------------------------
-- Get Departments Name That Has Students 
----------------------------------------------------------
-- joins
select distinct Dept_Name
from Student S inner join Department D
ON D.Dept_Id = S.Dept_Id

-- subqueries
select Dept_Name
from Department
where Dept_Id in (Select distinct Dept_Id from  Student where Dept_Id is not null)


------------------------------------------------------
-- Delete Student's grade who are Living In Mansoura
------------------------------------------------------
delete Stud_Course
from Stud_Course inner join Student
on Student.St_Id  = Stud_Course.St_Id
where St_Address = 'Mansoura'

delete from Stud_Course
where St_Id in (select St_ID from Student where St_Address = 'Mansoura' )

-- Best practice Is Using Join Instead Of Subquery


---------------------------------------------------------------------
----------------------------- Top -----------------------------------
-- Select All Data Of First 5 Students From Student Table 
---------------------------------
select Top 5 *
from Student

-- Select Id , First name and Age Of First 10 Students From Student Table 

select Top 10 St_Id,St_Fname, St_Age
from Student

-- Select All Data Of Last 5 Students From Student Table 
select Top 5 *
from Student
order by St_Id desc

-- Select Instructor who Has Highest Salary 
--max salary
select max(Salary)
from Instructor

select Top(1)*
from Instructor
order by Salary desc

-- Select Instructor who Has the 2nd Highest Salary 
select top 2 *
from Instructor
order by Salary desc

select Top 1*
from Instructor
where Salary < (select MAX(Salary)
from Instructor)--323423.00
order by Salary desc

-- Select Instructor who Has the 2nd Highest Salary using top only
select Top 1*
from(
select top 2 *
from Instructor
order by Salary desc) as HighestSalary
order by Salary

select MAX(Salary)
from Instructor

-- Select Instructor who Has the 2nd Highest Salary without using top
select MAX(Salary)
from Instructor
where Salary < (select MAX(Salary)
from Instructor)--323423.00

-- Select 25% From Students In Student Table
select top (25) Percent *
from Student

---------------------
-- Top with Ties 
-------------------------------
select top(5) with ties Salary
from Instructor
order by Salary

---------------------
-- Random Selection  
---------------------
select top 5*, NEWID() as newID
from Student
order by NEWID()

