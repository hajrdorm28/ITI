-- single line comment

/* 
multiline comment
*/

--shortcuts
--select * from Employee
--ctrl k + ctrl c , 
--ctrl k + ctrl u 

-------------------
--02 variables 
--1- global variable 
print @@version
print @@serverName

--2-local variables 
declare @name varchar(10) = 'Fatma'
--set @name = 'Ali'
print @name
set @name = 'Ali'
print @name

--------------------
--DDL (Data definition Language)
--create alter drop 

--1-create

create database STG03
use STG03


create table Employees (
SSN int primary key identity(1,1),
Fname varchar(10),
Lname varchar(10),
-- FullName as(Fname + ' '+Lname) persisted,
Gender Char,
Bdate Date,
--Age as (  - ) persisted,
Dnum int, -- foreign key
SuperSSn int Foreign key references Employees(SSN) --unary
)

create table Departments(
Dnum int Primary Key identity(10,10),
Dname varchar(20),
ManagerSSn int references Employees(SSN) unique not null,
HiringDate date
)

create table DeptLocations (
Dnum int references Departments(Dnum),
Location varchar(20) default 'cairo'
Primary key(Dnum, location)
)

create table Projects(
Pnum int primary key,
Pname varchar(20),
Location varchar(30),
City varchar(20),
Dnum int references Departments(Dnum) not null
)

create table Dependents(
Name varchar(30),
BDate datetime,
Gender Bit not null,
ESSN int references Employees(SSN) not null,
Primary key (Name, ESSn)
)

create table EmployeeProjects(
ESSN int references Employees(SSN),
Pnum int references Projects(Pnum),
NumOfHours int check (NumOfHours >= 0)
Primary Key (ESSn, Pnum)
)
--constraints
-- primary key  (unique+not null)
-- foriegn key 
-- unique -- not many
-- not null -- total 
-- check 
-- default 
-- persisted


--------------------
-- Alter (update structure)
---------------------

alter database STG03
modify name = STG031

--alter add
alter table Employees
add Test int

alter table Employees
add Constraint Unique_Test unique(Test)

--alter alter
alter table Employees
alter Column Gender Bit

alter table Employees
drop Constraint Unique_Test

alter table Employees
add foreign key (Dnum) references Departments(Dnum)

alter table Employees
drop Column SSN

alter table Employees
drop Column Test

------------------
-- drop
------------------
create table try (
id int, name char(5)
)
drop table try

drop database newnew

----------- Data Manipulation Language --------------
--===================================================
-- 1. Insert 
--===========
-- 1.1 Simple Insert  (Insert Just Only One Row)
-- -----------------------------------------------
Insert into Employees
values('fatma','alaa',1,'08-05-2025', null, null)

Insert into Employees(Fname)
values('ALi')

/* If a column is not in column_list, the Database Engine must be able to provide a value 
based on the definition of the column; otherwise, the row cannot be loaded. 
The Database Engine automatically provides a value for the column if the column:*/

-- 1. Has an IDENTITY property. The next incremental identity value is used.
-- 2. Has a default. The default value for the column is used.
-- 3. Has a timestamp data type. The current timestamp value is used.
-- 4. Is nullable. A null value is used.
-- 5. Is a computed column. The calculated value is used.

---------------------------------------------------
-- 1.2 Row Constructor Insert (More Than One Row)
--===============================================
Insert into Employees
values('Ahmed','alaa',1,'08-05-2025', null, null),
('Amr','alaa',2,'08-05-2025', null, null)

Insert into Employees(Fname)
values('ALi'),('Eman')

----------------------------------------------------------
-- 2. Update 
--===========

update Employees
set Lname = 'Mohamed'

update Employees
set Lname = 'Mostafa'
where SSN = 5

alter table Employees
add Salary int

update Employees
set Salary = Salary * 1.1
where Gender = 1 and Salary < 3000 

-------------------
-- 3. Delete
--===========
delete from Employees
where Fname = 'Ali'

--=================================================================
------------------- Delete And update Rules -----------------------
--=================================================================
delete from Department
where Dept_Id = 10

-- 1- cascade 
delete from Student
where Dept_Id = 10

delete from Department
where Dept_Id = 10
--The DELETE statement conflicted with the REFERENCE constraint "FK_Instructor_Department". 
-- The conflict occurred in database "ITI", table "dbo.Instructor", column 'Dept_Id'.

--1- cascade
delete from Instructor
where Dept_Id = 10

--2- set null
update Instructor
set Dept_Id = null
where Dept_Id = 10

delete from Department
where Dept_Id = 10

--3- set default 
update Instructor
set Dept_Id = 100 --invalid
where Dept_Id = 30


create table Try (
id int primary key,
Test int references Department(Dept_Id)
)
drop table Try

alter table Try
add Constraint FK_Test Foreign Key (Test) references Department(Dept_id)  on delete cascade on update set default



--self relationship (Using Code Only)
delete from Department
where Dept_Id = 40
/*
The DELETE statement conflicted with the SAME TABLE REFERENCE constraint "FK_Student_Student". The conflict occurred in database "ITI", table "dbo.Student", column 'St_super'.
The statement has been terminated.
*/

update Student
set St_super = null
where St_super in(select St_Id from Student where Dept_Id = 40)

select St_Id from Student where Dept_Id = 40

-------------------------------------------------------------------------
---------------- Data Query Language Category ----------------------------
---------------------------------------------------------------------------
use ITI
-- Display All Data For All Students
-------------------------------------
select *
from Student

select St_Id, St_Fname, St_Lname
from Student

select *
from Student
where Dept_Id = 20  and St_Age > 25

--------------------------------------------
-- Display Id , First Name And Age For Students That Their Age is in Range 23 , 30
-----------------------------------------------------------------------------------
select St_Id, St_Fname, St_Age
from Student
where St_Age >= 23 and  St_Age <= 30 

select St_Id, St_Fname, St_Age
from Student
where St_Age between 23 and 30 --23 30 included


--------------------------------------------
-- Display Id , First Name And Age For Students That Their Age is not in Range 23 , 30
-----------------------------------------------------------------------------------
select St_Id, St_Fname, St_Age
from Student
where St_Age < 23 or St_Age > 30 

select St_Id, St_Fname, St_Age
from Student
where St_Age not between 23 and 30 --23 30 included

-------------------------------------------------
-- Display Student Id , Student FName, Student Address Who Lives In Cairo Or Alex
----------------------------------------------------------------------------------------

select *
from Student
where St_Address = 'Cairo' or St_Address = 'Alex'

select *
from Student
where St_Address in( 'Cairo' ,'Alex','Tanta')

-------------------------------------------------
-- Display Student Id , Student FName, Student Address Who don't Lives In Cairo Or Alex
----------------------------------------------------------------------------------------

select *
from Student
where St_Address != 'Cairo' and St_Address <> 'Alex'

select *
from Student
where St_Address not in( 'Cairo' ,'Alex','Tanta')


--  Display All Data Of All Students Who Hasn't a Supervisor
------------------------------------------------------------
select * 
from Student
where St_super is null

--  Display All Data Of All Students Who Has a Supervisor
------------------------------------------------------------
select * 
from Student
where St_super is not null


---------------------------------------------------------------------
-- Display student where second character of Their First name is 'a' 
---------------------------------------------------------------------
select *
from Student
where St_Fname like '_a%'

/*
Wildcard Characters =>
_ : represents one, single character saly aa sab '_a_b'  =>saby
% : represents zero, one, or multiple characters 
[] : Matches any single character within the specified range  _[abc]% 
[^]: Matches any single character that is not within the range  [^abc] m  s f 
*/

-- Examples
-- _a => aa ba sa
-- _a% => 
-- [sa]% => samy amal
-- sa% => sara samy salma
-- [a-m]% => 
-- [a_m]% => a _ m
-- [%]% => %word 
-- [^a-m]% => 
-----------------------------------
-- Display Data Without Duplication
---------------------------------------------------------------------
select distinct St_Fname
from Student

-----------------------------------
-- Display First Name Of Student In Order 
---------------------------------------

select *
from Student
order by St_Fname asc

---------------------------------------

select *
from Student
order by St_Fname desc

select *
from Student
order by St_Fname , St_Age desc

select St_Fname, St_Age
from Student
order by 1 ,2 desc