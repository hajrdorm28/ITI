--=================================================================
----------------------------- Schema ------------------------------
--=================================================================

select * from dbo.Student

select * from [DESKTOP-R3S5HBH\SQLEXPRESS].[ITI].[dbo].[Student]
--servername.dbname.schema.object]

print @@servername


--SQL Servers parsing and compilation rules.
--"Incorrect syntax near 'CREATE'. Must be the only statement in the batch."

go
create Schema HR
go

-- Transfer Database Object From Schema To Another Schema
-------------------------------------------------------------------
alter schema HR
Transfer Student

select * from HR.Student

alter schema Dbo
Transfer HR.Student

create table HR.test(id int, name varchar(20))

-- Drop Schema
-------------------------------------------------------------------
drop schema HR
-- Cannot drop schema 'HR' because it is being referenced by object 'test'.
drop Table  HR.test

drop schema HR
--=================================================================
------------------------- Union Family ----------------------------
--=================================================================

use ITI

-- union , union all, except, intersect
alter schema dbo
transfer Hr.Student

select  Ins_Name
from Instructor
union -- distinct 
select St_Fname
from Student

select  Ins_Name
from Instructor
union All --  no distinct 
select St_Fname
from Student


select  Ins_Name , Ins_Degree  
from Instructor
union -- distinct 
select St_Fname, St_Age
from Student  --invalid

-- intersect 

select  Ins_Name
from Instructor
intersect
select St_Fname
from Student

--except

select  Ins_Name
from Instructor
except 
select St_Fname
from Student



-- data not metadata
-- from varchar - int 
-- Conversion failed when converting the nvarchar value 'Master' to data type int.


--=================================================================
-------------------------- Select Into ------------------------ DDL
--=================================================================
-- DQL+DDL+Dml
-- 1 create
-- 2 insert
--copy table  without constraint

select * into NewProject --ITI .dbo 
from MyCompany.dbo.Project


select * into NewStudent
from Student

--There is already an object named 'NewStudent' in the database. 
--internally create


select * into NewStudent
from Student
where 1=2

--=================================================================
-------------------- Insert Based On Select  -------------------DML
--=================================================================

insert into NewStudent
select * from Student

insert into NewStudent2 --invalid
select * from Student
--Invalid object name 'NewStudent2'.

--=================================================================
-------------------- User Defined Functions -----------------------
--=================================================================
-- 1-Scalar Function
-------------------------------------------------------------------
-- Create Function Take Id Of Student And Returns His Full Name 
-------------------------------------------------------------------
go
create Function GetStudentNamebyID (@id int)
RETURNS varchar(50)
begin
	declare @studentName varchar(50)

	select @studentName = CONCAT_WS(' ',St_Fname, St_Lname)
	from Student
	where St_Id = @id

	Return @studentName
end
go

--builtin function
select dbo.GetStudentNamebyID(6)
select dbo.GetStudentNamebyID('6') [Full name]
print dbo.GetStudentNamebyID('6')

select GetStudentNamebyID(6) --invalid

-------------------------------------------------------------------
-- Create Function Take Department Name And Return Name Of Its Manager
-------------------------------------------------------------------
go
create Function GetDeptMgrbydeptName (@name nvarchar(50))
returns nvarchar(50)
begin
	declare @manager nvarchar(50)
	select @manager = Ins_Name
	from Department d inner join Instructor I
	on d.Dept_Id = I.Dept_Id and Dept_Name = @name
	Return @manager
end

go
select dbo.GetDeptMgrbydeptName('java') [Name]
select dbo.GetDeptMgrbydeptName('Ahmed') [Name]
print  dbo.GetDeptMgrbydeptName('Ahmed')

-------------------------------------------
--Alter Function

go
create or Alter Function HR.GetDeptMgrbydeptName3 (@name nvarchar(50))
returns nvarchar(50)
begin
	declare @manager nvarchar(50)
	select @manager = Ins_Name
	from Department d inner join Instructor I
	on d.Dept_Id = I.Dept_Id and Dept_Name = @name
	Return @manager
end
go

select HR.GetDeptMgrbydeptName3('java') [Name]

alter schema HR
transfer dbo.GetDeptMgrbydeptName3

drop Function Hr.GetDeptMgrbydeptName3
---------------------------------------
-- 2- inline table-valued Function
-------------------------------
-- Create Function That Take Department Id 
-- and Return Instructors That Works In It --table 
-----------------------------------------------------

go
create or alter Function GetInsbyDeptId (@deptId int)
Returns table 
as
Return 
(
	select *
	from Instructor
	where Dept_Id = @deptId
)
go

select *
from GetInsbyDeptId(70)


select Ins_Id, Ins_Name
from dbo.GetInsbyDeptId(15)

---------------------------------------
-- 2- multi statement table-valued Function
------------------------------------
-------------------------------------------------------------------
-- Create Function That Take Format And Return Student Name Based 
-- On Format (First , Last , Fullname)
-------------------------------------------------------------------
go
create or alter Function GetStudentonFormat(@format varchar(20))
returns @data table (id int, name varchar(50))
as
begin
	--insert on select
	if @format = 'first'
		insert into @data
		select St_Id, St_Fname
		from Student

	else if @format = 'last'
		insert into @data
		select St_Id, St_Lname
		from Student

	else if @format = 'full name'
		insert into @data
		select St_Id, Concat_ws(' ', St_Fname,St_Lname)
		from Student
	return 
end

go

select *
from GetStudentonFormat('First')

select *
from GetStudentonFormat('last')

select *
from GetStudentonFormat('full name')

select *
from GetStudentonFormat('ali')


--=================================================================
------------------------ Stored procedures ------------------------
--=================================================================
-- Get Stduent by Id 
--------------------------------------------------------------------

go
create Procedure SPGetStudentById @id int
as
	select *
	from Student
	where St_Id = @id
go

execute SPGetStudentById 6
exec SPGetStudentById
SPGetStudentById '6'

--alter
go
create or alter Procedure SPGetStudentById2 @id int
with encryption
as
	select *
	from Student
	where St_Id = @id
go

execute SPGetStudentById2 6

declare @id int = 6
exec SPGetStudentById2 @id

declare @id int = 6
SPGetStudentById2 @id --invalid

go
sp_helptext SPGetStudentById2

--The text for object 'SPGetStudentById2' is encrypted.

alter Schema HR
Transfer SPGetStudentById2

exec Hr.SPGetStudentById2 6

--=================================================================
---------------------- Insert Based On Execute --------------------
--=================================================================
go
create or alter proc SPGetStudentByAddress @address varchar(30)
with encryption
as
	select St_Fname, St_Id, St_Address
	from Student
	where St_Address = @address
go


exec SPGetStudentByAddress 'cairo'  

create table StudentByAddress(
name varchar(30), id int primary key, address varchar(30)
)

insert into StudentByAddress 
exec SPGetStudentByAddress 'Alex'
-- where St_Fname = '' invalid 
-- no codition

-- Column name or number of supplied values does not match table definition.

--where St_Id = -- no condition
/*Msg 8114, Level 16, State 1, Procedure SPGetStudentByAddress, Line 4 [Batch Start Line 271]
Error converting data type nvarchar to int.*/
--================================================================
-------------------- Stored procedure Examples --------------------
--=================================================================
-- hide business rules, --error handling --try catch --dml

go
create or alter proc SPdeleteTopicbyId @id int
with encryption
as
	set nocount on -- off
	begin try 
		delete from Topic
		where Top_Id = @id
	end try
	begin catch
		print Error_Message()

	end catch
go

SPdeleteTopicbyId 5
--(1 row affected)
-------------------------------------------------------------------
-- Input Parameter  
-------------------------------------------------------------------

go
create or alter proc SPsubtractDate @x int = 5 , @y varchar(10) = '3'
with encryption
as
	select @x - @y
go

SPsubtractDate 4, 2 --pass by order
go
SPsubtractDate '2', 4 --pass by order

go
SPsubtractDate 4 --pass by order

go
SPsubtractDate @y = '2', @x = 4 --pass by name
--Must pass parameter number 2 and subsequent parameters as '@name = value'. After the form '@name = value' has been used, all subsequent parameters must be passed in the form '@name = value'.
go
SPsubtractDate @y = '2'--pass by name
--Procedure or function 'SPsubtractDate' expects parameter '@x', which was not supplied.
go
SPsubtractDate --pass using default

-------------------------------------------------------------------
-- Output Parameter  
-------------------------------------------------------------------
go
create or alter proc SpGetStudentNameandAgebyId @id int , @name varchar(20) out, @age int out
with encryption
as 
	select @name = St_Fname, @age = St_Age
	from Student 
	where St_Id = @id
go

declare @name varchar(20), @age int
exec SpGetStudentNameandAgebyId 6, @name out, @age out
--select @name 
Print @age
-- Procedure or function 'SpGetStudentNameandAgebyId' expects parameter '@age', which was not supplied.

-------------------------------------------------------------------
-- Input Output Parameter  
-------------------------------------------------------------------
go
create or alter proc SpGetStudentNameandAgebyId2 @data int out
with encryption
as 
	select @data = St_Age
	from Student 
	where St_Id = @data
go


declare @data int
exec SpGetStudentNameandAgebyId2 6 --constant
print @data

go
declare @data int --null
exec SpGetStudentNameandAgebyId2 @data out 
print @data

go
declare @data int = 6 --must be assigned
exec SpGetStudentNameandAgebyId2 @data out 
print @data


--=================================================================
---------------------------- Views --------------------------------
--=================================================================
-- Basic user defined view [Standard view]

-- Students In Cairo
-------------------------------------------------------------------
go
Create or alter view VCairoStudents 
as
	select St_Id, St_Fname, St_Address
	from Student
	where  St_Address = 'Cairo'
go

select St_ID, St_Fname from VCairoStudents

-- Students In Alex
-------------------------------------------------------------------
-------------------------------------------------------------------
go 
create or alter view VAlexStudents
with encryption
as
	select Top 2 St_Id, St_Fname, St_Address
	from Student
	where St_Address = 'Alex'
	order by St_Fname --invalid

/*Msg 1033, Level 15, State 1, Procedure VAlexStudents, Line 6 [Batch Start Line 384]
The ORDER BY clause is invalid in views, inline functions, derived tables, subqueries, and common table expressions, unless TOP, OFFSET or FOR XML is also specified.
*/
go
select *
from VAlexStudent

-------------------------------------------------------------------
-- Students And Their Departments
-------------------------------------------------------------------
-------------------------------------------------------------------
-- Hide Source Code Of View 
-------------------------------------------------------------------
go
Create or alter view Hr.VStudentsInDepts 
with encryption
as
	select s.St_Fname, d.Dept_Name, d.Dept_Id
	from Student S inner join Department D
	on s.Dept_Id = d.Dept_Id
go

sp_helptext 'Hr.VStudentsInDepts'

select * 
from VStudentsInDepts
where Dept_ID = 30 --invalid

alter schema HR
transfer VStudentsInDepts

select * 
from Hr.VStudentsInDepts
where Dept_ID = 30 --invalid

-------------------------------------------------------------------
-- Hide Meta Data Of View 
-------------------------------------------------------------------
go
Create or alter view Hr.VStudentsInDepts  (StudentName, DeptName, DeptId)
with encryption
as
	select s.St_Fname [StudentName], d.Dept_Name, d.Dept_Id , --Avg()[],CONCAT_WS()[]
	from Student S inner join Department D
	on s.Dept_Id = d.Dept_Id
go


select * 
from Hr.VStudentsInDepts
where Dept_ID = 30 --invalid

-------------------------------------------------------------------
-- 2. Partitioned Views
-------------------------------------------------------------------

go
create or alter View VStudentsCairoAlex 
with encryption
as

select St_ID, ST_Fname, St_Address
from Student
where St_Address  = 'Cairo' 
union
select St_ID, ST_Fname, St_Address
from Student
where St_Address  = 'Alex'


go
create or alter View VStudentsCairoAlex2 
with encryption
as
select *
from VCairoStudents
union
select *
from VCairoStudents


-- security 


--=================================================================
----------------------- Views With DMl ----------------------------
--=================================================================

--insert 
insert into VCairoStudents
values(1234, 'Fatma', 'Cairo')


insert into VCairoStudents(St_Id,St_Fname, St_Address)
values( 5050,'Samy', 'Cairo')

-- Cannot insert the value NULL into column 'St_Id', table 'ITI.dbo.Student'; column does not allow nulls. INSERT fails.
go
Create or alter view Hr.VStudentsInDepts  (StudentId, StudentName, DeptName, DeptId)
with encryption
as
	select S.St_Id, s.St_Fname , d.Dept_Name, d.Dept_Id  --Avg()[],CONCAT_WS()[]
	from Student S inner join Department D
	on s.Dept_Id = d.Dept_Id
go

insert into Hr.VStudentsInDepts
values('Manar','dept', 100) 
--View or function 'Hr.VStudentsInDepts' is not updatable because the modification affects multiple base tables.

insert into Hr.VStudentsInDepts (StudentName)
values('Manar') 
--Cannot insert the value NULL into column 'St_Id', table 'ITI.dbo.Student'; column does not allow nulls. INSERT fails.


insert into Hr.VStudentsInDepts (StudentId,StudentName)
values(1020,'Manar')


insert into Hr.VStudentsInDepts (DeptId,DeptName)
values(100,'Dept')


--update 

update VCairoStudents
set St_Fname = 'Samir'
where St_Id = 5050

/*
go
Create or alter view Hr.VStudentsInDepts  (StudentId, StudentName, DeptName, DeptId)
with encryption
as
	select S.St_Id, s.St_Fname , d.Dept_Name, d.Dept_Id  --Avg()[],CONCAT_WS()[]
	from Student S inner join Department D
	on s.Dept_Id = d.Dept_Id
go
*/
update Hr.VStudentsInDepts
set StudentName = 'Mariam',  DeptName = 'C++'

--View or function 'Hr.VStudentsInDepts' is not updatable because the modification affects multiple base tables.


update Hr.VStudentsInDepts
set StudentName = 'Salma'
where StudentId = 6

-- delete
delete from VCairoStudents
where St_Id = 5050

--=================================================================
-------------------- Views With Check Option ----------------------
--=================================================================
--insert
insert VCairoStudents 
values(7000,'Anas','Cairo')

--The attempted insert or update failed because the target view either specifies WITH CHECK OPTION or spans a view that specifies WITH CHECK OPTION and one or more rows resulting from the operation did not qualify under the CHECK OPTION constraint.

go
Create or alter view VCairoStudents 
as
	select St_Id, St_Fname, St_Address
	from Student
	where  St_Address = 'Cairo'  with check option
go

--update
use ITI

-- condition must be satisfied
update VCairoStudents
set St_Address = 'Alex'
where St_ID = 11


-- not related to with check option
update VCairoStudents
set St_Fname = 'Salma'
where St_ID = 11


update VCairoStudents
set St_Address = 'Alex'
where St_ID = 10
--The attempted insert or update failed because the target view either specifies WITH CHECK OPTION or spans a view that specifies WITH CHECK OPTION and one or more rows resulting from the operation did not qualify under the CHECK OPTION constraint.

--delete  not affected
delete from VCairoStudents
where St_ID = 10

delete from VCairoStudents
where St_ID = 6000
--(0 rows affected) not related


--ranking functions

--triggers, indexes, TCL

